<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bigEvents/index.html.twig */
class __TwigTemplate_ad4d6930df44b7ee70d18d5e879248a1df87f9d77e618cbe269075b8e8766caf extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'stylesheet' => [$this, 'block_stylesheet'],
            'jumbohead' => [$this, 'block_jumbohead'],
            'jumbobody' => [$this, 'block_jumbobody'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bigEvents/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bigEvents/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "bigEvents/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_stylesheet($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheet"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheet"));

        // line 4
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/jumbo.css"), "html", null, true);
        echo "\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_jumbohead($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jumbohead"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jumbohead"));

        echo "Welcome to Big Events";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_jumbobody($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jumbobody"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jumbobody"));

        echo "Be the first to know about all the upcoming events happening in your city
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "<div class=\"container\">
\t<div class=\"row\">
\t\t<div class=\"col-12 d-flex justify-content-center\">
\t\t\t<h1>Events</h1>
\t\t</div>
\t\t";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["bigEvents"]) ? $context["bigEvents"] : $this->getContext($context, "bigEvents")));
        foreach ($context['_seq'] as $context["_key"] => $context["e"]) {
            // line 19
            echo "\t\t    <div class=\"card col-3 m-3\" style=\"width: 18rem;\">
\t\t    <img src=";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "image", []), "html", null, true);
            echo " class=\"card-img-top\" alt=\"...\">
\t\t    <div class=\"card-body\">
\t\t    <h5 class=\"card-title\">";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "name", []), "html", null, true);
            echo "</h5>
\t\t    <p class=\"card-text\">";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "description", []), "html", null, true);
            echo "</p>
\t\t \t </div>
\t\t  \t<ul class=\"list-group list-group-flush\">
\t\t    <li class=\"list-group-item\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "timeDate", []), "html", null, true);
            echo "</li>
\t\t  \t</ul>
\t\t \t <ul class=\"list-group list-group-flush\">
\t\t\t<li class=\"list-group-item\">
\t\t\t<a href=\"/bigEvents/edit/";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-warning\">Edit</a>
\t\t\t<a href=\"/bigEvents/delete/";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>
\t\t\t<button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#taskModal";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "id", []), "html", null, true);
            echo "\">View</button></li>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['e'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "\t\t
\t</div>
</div>  

<!-- Modal -->
";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["bigEvents"]) ? $context["bigEvents"] : $this->getContext($context, "bigEvents")));
        foreach ($context['_seq'] as $context["_key"] => $context["e"]) {
            // line 41
            echo "    
<div class=\"modal fade\" id=\"taskModal";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "id", []), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"exampleModalLabel\">";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "name", []), "html", null, true);
            echo "</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
      Event: ";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "name", []), "html", null, true);
            echo "
      <hr>
      Description: ";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "description", []), "html", null, true);
            echo "
      <hr>
      When: ";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "timeDate", []), "html", null, true);
            echo "
       <hr>
      Capacity: ";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "capacity", []), "html", null, true);
            echo "
      <hr>
      Email: ";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "email", []), "html", null, true);
            echo "
      <hr>
      Number: ";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "number", []), "html", null, true);
            echo "
      <hr>
      Where: ";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "address", []), "html", null, true);
            echo "
       <hr>
      Website: ";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "url", []), "html", null, true);
            echo "
      <hr>
      Category: ";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["e"], "type", []), "html", null, true);
            echo "
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['e'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bigEvents/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 68,  240 => 66,  235 => 64,  230 => 62,  225 => 60,  220 => 58,  215 => 56,  210 => 54,  205 => 52,  196 => 46,  189 => 42,  186 => 41,  182 => 40,  175 => 35,  166 => 32,  162 => 31,  158 => 30,  151 => 26,  145 => 23,  141 => 22,  136 => 20,  133 => 19,  129 => 18,  122 => 13,  113 => 12,  94 => 9,  76 => 7,  63 => 4,  54 => 3,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block stylesheet %}
<link rel=\"stylesheet\" href=\"{{ asset('css/jumbo.css')}}\">
{% endblock %}

{% block jumbohead %}Welcome to Big Events{% endblock %}

{% block jumbobody %}Be the first to know about all the upcoming events happening in your city
{% endblock %}

{% block body %}
<div class=\"container\">
\t<div class=\"row\">
\t\t<div class=\"col-12 d-flex justify-content-center\">
\t\t\t<h1>Events</h1>
\t\t</div>
\t\t{% for e in bigEvents %}
\t\t    <div class=\"card col-3 m-3\" style=\"width: 18rem;\">
\t\t    <img src={{e.image}} class=\"card-img-top\" alt=\"...\">
\t\t    <div class=\"card-body\">
\t\t    <h5 class=\"card-title\">{{e.name}}</h5>
\t\t    <p class=\"card-text\">{{e.description}}</p>
\t\t \t </div>
\t\t  \t<ul class=\"list-group list-group-flush\">
\t\t    <li class=\"list-group-item\">{{e.timeDate}}</li>
\t\t  \t</ul>
\t\t \t <ul class=\"list-group list-group-flush\">
\t\t\t<li class=\"list-group-item\">
\t\t\t<a href=\"/bigEvents/edit/{{e.id}}\" class=\"btn btn-warning\">Edit</a>
\t\t\t<a href=\"/bigEvents/delete/{{e.id}}\" class=\"btn btn-danger\">Delete</a>
\t\t\t<button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#taskModal{{e.id}}\">View</button></li>
\t\t\t</div>
\t\t{% endfor %}
\t\t
\t</div>
</div>  

<!-- Modal -->
{% for e in bigEvents %}
    
<div class=\"modal fade\" id=\"taskModal{{e.id}}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"exampleModalLabel\">{{e.name}}</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
      Event: {{e.name}}
      <hr>
      Description: {{e.description}}
      <hr>
      When: {{e.timeDate}}
       <hr>
      Capacity: {{e.capacity}}
      <hr>
      Email: {{e.email}}
      <hr>
      Number: {{e.number}}
      <hr>
      Where: {{e.address}}
       <hr>
      Website: {{e.url}}
      <hr>
      Category: {{e.type}}
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
{% endfor %}
{% endblock %}", "bigEvents/index.html.twig", "/Users/sarahley/Desktop/symfony101/bigEvents/app/Resources/views/bigEvents/index.html.twig");
    }
}
