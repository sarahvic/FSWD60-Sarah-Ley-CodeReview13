<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use AppBundle\Entity\Bigevents;

class BigEventsController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        //getting bigEvents table from database
    $em = $this->getDoctrine()->getManager();
    $events = $em->getRepository(Bigevents::class)->findAll();
      return $this->render('bigEvents/index.html.twig', array("bigEvents"=>$events));
   }
}
