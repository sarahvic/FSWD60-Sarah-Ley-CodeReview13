<?php
namespace AppBundle\Controller;
// We include the entity that we create in our Controller file
use AppBundle\Entity\Bigevents;
use Symfony\Component\Routing\Annotation\Route;
// use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

// Now we need some classes in our Controller because we need that in our form (for the inputs that we will create)
use Symfony\Component\Form\Extension\Core\Type\TextType;
// use Symfony\Component\Form\Extension\Core\Type\FormType;
// use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
// use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
class CrudController extends Controller
{
  
    /**
    * @Route("/bigEvents/new", name="bigEvents_create")
    */
   public function createAction(Request $request){

// Here we create an object from the class that we made
       $event = new Bigevents;

/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($event)
       ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('timeDate', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('number', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
      ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);


/* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
       if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $image = $form['image']->getData();
           $name = $form['name']->getData();
           $timeDate = $form['timeDate']->getData();
           $description = $form['description']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $number = $form['number']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
// Here we will get the current date
          


/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $event->setImage($image);
           $event->setName($name);
           $event->setTimeDate($timeDate);
           $event->setDescription($description);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setNumber($number);
           $event->setAddress($address);
           $event->setUrl($url);
           $event->setType($type);
           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('homepage');
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
       return $this->render('bigEvents/new.html.twig', array('form' => $form->createView()));
   }
    /**
    * @Route("/bigEvents/edit/{id}", name="bigEvents_edit")
    */
   public function editAction( $id, Request $request){

     $event= $this->getDoctrine()->getRepository('AppBundle:Bigevents')->find($id);

           $event->setImage($event->getImage());
           $event->setName($event->getName());
           $event->setTimeDate($event->getTimeDate());
           $event->setCapacity($event->getCapacity());
           $event->setEmail($event->getEmail());
           $event->setNumber($event->getNumber());
           $event->setAddress($event->getAddress());
           $event->setUrl($event->getUrl());
           $event->setType($event->getType());
           
        $form = $this->createFormBuilder($event)
       ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('timeDate', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('number', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
      ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);
       if($form->isSubmitted() && $form->isValid()){

           $image = $form['image']->getData();
           $name = $form['name']->getData();
           $timeDate = $form['timeDate']->getData();
           $description = $form['description']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $number = $form['number']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $em = $this->getDoctrine()->getManager();
           $event = $em->getRepository('AppBundle:Bigevents')->find($id);
           $event->setImage($image);
           $event->setName($name);
           $event->setTimeDate($timeDate);
           $event->setDescription($description);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setNumber($number);
           $event->setAddress($address);
           $event->setUrl($url);
           $event->setType($type);
          
        
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Updated'
                   );
           return $this->redirectToRoute('homepage');
       }


       // replace this example code with whatever you need
       return $this->render('bigEvents/edit.html.twig', array('bigEvents' => $event, 'form' => $form->createView()));
   }
    /**
    * @Route("/bigEvents/delete/{id}", name="bigEvents_delete")
    */
   public function deleteAction($id){
          $em = $this->getDoctrine()->getManager();
          $event = $em->getRepository('AppBundle:Bigevents')->find($id);
          $em->remove($event);
          $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Removed'
                   );
            return $this->redirectToRoute('homepage');
   }
}